from radar.analysis.scoring import PresenceAnalysis, score_presence


def test_no_website_and_no_instagram_is_max_score() -> None:
    result = score_presence(PresenceAnalysis(has_website=False, has_instagram_link=False))
    assert result.score == 100
    assert "Não possui site" in result.reasons


def test_healthy_presence_scores_zero() -> None:
    result = score_presence(
        PresenceAnalysis(
            has_website=True,
            website_reachable=True,
            https=True,
            mobile_friendly=True,
            pagespeed_mobile=90,
            has_cta=True,
            has_instagram_link=True,
            instagram_inactive=False,
        )
    )
    assert result.score == 0
    assert result.reasons == []


def test_unknown_values_do_not_add_points() -> None:
    result = score_presence(PresenceAnalysis(has_website=True, has_instagram_link=True))
    assert result.score == 0


def test_site_problems_add_up_with_reasons() -> None:
    result = score_presence(
        PresenceAnalysis(
            has_website=True,
            https=False,
            mobile_friendly=False,
            pagespeed_mobile=30,
            has_cta=False,
            has_instagram_link=True,
            instagram_inactive=True,
        )
    )
    assert result.score == 10 + 15 + 10 + 10 + 20
    assert len(result.reasons) == 5


def test_unreachable_site_skips_site_details() -> None:
    result = score_presence(
        PresenceAnalysis(
            has_website=True, website_reachable=False, https=False, has_instagram_link=True
        )
    )
    assert result.score == 45


def test_custom_weights_override_defaults() -> None:
    result = score_presence(
        PresenceAnalysis(has_website=False, has_instagram_link=True), weights={"no_website": 30}
    )
    assert result.score == 30
