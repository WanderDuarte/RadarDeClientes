"""Contrato dos canais de envio (e-mail, WhatsApp Cloud API, Instagram...)."""

from typing import Protocol

from radar.models import Lead


class Sender(Protocol):
    channel: str

    def send(self, lead: Lead, body: str) -> str:
        """Envia a mensagem e devolve o id dela no provedor."""
        ...
