"""Ponto único de envio: nada sai sem passar pelo ComplianceGuard.

Ordem: guarda → (dry-run?) → envio real → registro da mensagem → auditoria.
"""

from dataclasses import dataclass

from sqlalchemy.orm import Session

from radar.audit import record_audit
from radar.channels.base import Sender
from radar.compliance.guard import ComplianceGuard
from radar.config import Settings
from radar.models import DIRECTION_OUT, MSG_DRY_RUN, MSG_SENT, Lead, Message


@dataclass(frozen=True)
class DispatchResult:
    sent: bool
    status: str  # "sent" | "dry_run" | "blocked"
    reason: str


def dispatch_message(
    session: Session,
    guard: ComplianceGuard,
    settings: Settings,
    sender: Sender,
    lead: Lead,
    channel: str,
    body: str,
    *,
    approved: bool = False,
) -> DispatchResult:
    if sender.channel != channel:
        raise ValueError(f"Sender do canal {sender.channel!r} usado para o canal {channel!r}")

    decision = guard.check_send(lead, channel, approved=approved)
    if not decision.allowed:
        record_audit(session, "send_blocked", lead.id, channel=channel, reason=decision.reason)
        session.commit()
        return DispatchResult(False, "blocked", decision.reason)

    if settings.dry_run:
        session.add(
            Message(
                lead_id=lead.id,
                channel=channel,
                direction=DIRECTION_OUT,
                body=body,
                status=MSG_DRY_RUN,
                created_at=guard.now(),
            )
        )
        record_audit(session, "message_dry_run", lead.id, channel=channel)
        session.commit()
        return DispatchResult(False, "dry_run", "dry_run_enabled")

    provider_id = sender.send(lead, body)
    session.add(
        Message(
            lead_id=lead.id,
            channel=channel,
            direction=DIRECTION_OUT,
            body=body,
            status=MSG_SENT,
            provider_message_id=provider_id,
            created_at=guard.now(),
        )
    )
    record_audit(session, "message_sent", lead.id, channel=channel)
    session.commit()
    return DispatchResult(True, "sent", "ok")
