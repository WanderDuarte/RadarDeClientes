"""Schemas da API (entrada e saída)."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class LeadCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    category: str | None = None
    address: str | None = None
    city: str | None = None
    phone: str | None = None
    email: str | None = None
    website: str | None = None
    instagram_url: str | None = None
    source: str = "manual"
    source_id: str | None = None


class LeadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    category: str | None
    address: str | None
    city: str | None
    phone: str | None
    email: str | None
    website: str | None
    instagram_url: str | None
    source: str
    source_id: str
    score: int | None
    score_reasons: list[str]
    status: str
    created_at: datetime
