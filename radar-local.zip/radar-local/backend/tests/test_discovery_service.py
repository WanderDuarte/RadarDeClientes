from sqlalchemy import func, select
from sqlalchemy.orm import Session

from radar.discovery.base import PlaceCandidate
from radar.discovery.service import save_candidates
from radar.models import Lead


def _count(session: Session) -> int:
    return session.scalar(select(func.count()).select_from(Lead)) or 0


def test_save_candidates_deduplicates(session: Session) -> None:
    a = PlaceCandidate(source="osm", source_id="1", name="Loja 1", city="Araçatuba")
    b = PlaceCandidate(source="osm", source_id="2", name="Loja 2")

    assert save_candidates(session, [a, a, b]) == 2  # duplicado dentro do lote
    assert save_candidates(session, [a, b]) == 0  # duplicado já salvo
    assert _count(session) == 2


def test_same_source_id_in_different_sources_is_allowed(session: Session) -> None:
    items = [
        PlaceCandidate(source="osm", source_id="1", name="Loja"),
        PlaceCandidate(source="google", source_id="1", name="Loja"),
    ]
    assert save_candidates(session, items) == 2
