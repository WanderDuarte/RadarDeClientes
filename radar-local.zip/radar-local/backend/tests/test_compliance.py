from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy.orm import Session

from radar.compliance.guard import ComplianceGuard, is_opt_out, normalize_phone
from radar.models import (
    DIRECTION_IN,
    DIRECTION_OUT,
    MSG_RECEIVED,
    MSG_SENT,
    Consent,
    Lead,
    Message,
)
from tests.conftest import make_lead, make_settings

# 19/11/2026 é quinta-feira. São Paulo está em UTC-3.
THURSDAY_NOON = datetime(2026, 11, 19, 15, 0, tzinfo=UTC)  # 12h em São Paulo
THURSDAY_NIGHT = datetime(2026, 11, 20, 1, 0, tzinfo=UTC)  # 22h em São Paulo
SATURDAY_NOON = datetime(2026, 11, 21, 15, 0, tzinfo=UTC)  # sábado, 12h


def make_guard(
    session: Session, now: datetime = THURSDAY_NOON, **settings: object
) -> ComplianceGuard:
    return ComplianceGuard(session, make_settings(**settings), now=lambda: now)


def add_basis(session: Session, lead: Lead, channel: str = "email") -> None:
    session.add(Consent(lead_id=lead.id, channel=channel, basis="legitimate_interest"))
    session.commit()


def add_message(
    session: Session, lead: Lead, channel: str, direction: str, status: str, when: datetime
) -> None:
    session.add(
        Message(
            lead_id=lead.id,
            channel=channel,
            direction=direction,
            body="x",
            status=status,
            created_at=when,
        )
    )
    session.commit()


def test_normalize_phone() -> None:
    assert normalize_phone("(18) 99999-0000") == "5518999990000"
    assert normalize_phone("+55 18 99999-0000") == "5518999990000"


@pytest.mark.parametrize(
    "text",
    [
        "Pare",
        "STOP",
        "sair",
        "pode parar",
        "Não quero receber mais mensagens",
        "nao me envie mais nada, por favor",
        "Por favor, parem de me mandar isso",
        "quero me descadastrar",
    ],
)
def test_opt_out_detected(text: str) -> None:
    assert is_opt_out(text)


@pytest.mark.parametrize(
    "text",
    [
        "Qual o preço do site?",
        "Quero saber mais",
        "vou sair para almoçar, depois conversamos sobre o orçamento",
        "",
    ],
)
def test_normal_messages_are_not_opt_out(text: str) -> None:
    assert not is_opt_out(text)


def test_suppressed_lead_is_blocked_everywhere(session: Session) -> None:
    lead = make_lead(session)
    add_basis(session, lead)
    guard = make_guard(session)
    guard.suppress_lead(lead, "opt_out")
    session.commit()

    decision = guard.check_send(lead, "email", approved=True)
    assert (decision.allowed, decision.reason) == (False, "suppressed")


def test_suppression_matches_formatted_phone_and_email_case(session: Session) -> None:
    lead = make_lead(session, phone="18 99999-0000", email="Contato@Padaria.com")
    guard = make_guard(session)
    guard.add_suppression("phone", "+55 (18) 99999-0000", "opt_out")
    assert guard.is_suppressed(lead)

    other = make_lead(session, phone=None, email="CONTATO@padaria.com")
    guard.add_suppression("email", "contato@padaria.com", "opt_out")
    assert guard.is_suppressed(other)


def test_add_suppression_rejects_invalid_kind(session: Session) -> None:
    with pytest.raises(ValueError):
        make_guard(session).add_suppression("sms", "123", "x")


def test_whatsapp_cold_contact_is_blocked(session: Session) -> None:
    lead = make_lead(session)
    decision = make_guard(session).check_send(lead, "whatsapp", approved=True)
    assert decision.reason == "no_inbound_message"
    assert not decision.allowed


def test_whatsapp_reply_inside_window_is_allowed(session: Session) -> None:
    lead = make_lead(session)
    add_message(
        session, lead, "whatsapp", DIRECTION_IN, MSG_RECEIVED, THURSDAY_NOON - timedelta(hours=2)
    )
    assert make_guard(session).check_send(lead, "whatsapp").allowed


def test_whatsapp_reply_after_window_is_blocked(session: Session) -> None:
    lead = make_lead(session)
    add_message(
        session, lead, "whatsapp", DIRECTION_IN, MSG_RECEIVED, THURSDAY_NOON - timedelta(hours=30)
    )
    decision = make_guard(session).check_send(lead, "whatsapp")
    assert decision.reason == "reply_window_closed"


def test_inbound_on_other_channel_does_not_open_whatsapp(session: Session) -> None:
    lead = make_lead(session)
    add_message(session, lead, "instagram", DIRECTION_IN, MSG_RECEIVED, THURSDAY_NOON)
    assert make_guard(session).check_send(lead, "whatsapp").reason == "no_inbound_message"
    assert make_guard(session).check_send(lead, "instagram").allowed


def test_email_requires_approval(session: Session) -> None:
    lead = make_lead(session)
    add_basis(session, lead)
    assert make_guard(session).check_send(lead, "email").reason == "approval_required"


def test_email_requires_recorded_legal_basis(session: Session) -> None:
    lead = make_lead(session)
    decision = make_guard(session).check_send(lead, "email", approved=True)
    assert decision.reason == "no_legal_basis_recorded"


def test_email_allowed_when_everything_is_in_place(session: Session) -> None:
    lead = make_lead(session)
    add_basis(session, lead)
    assert make_guard(session).check_send(lead, "email", approved=True).allowed


def test_email_can_skip_approval_only_if_configured(session: Session) -> None:
    lead = make_lead(session)
    add_basis(session, lead)
    guard = make_guard(session, require_approval=False)
    assert guard.check_send(lead, "email").allowed


@pytest.mark.parametrize("when", [THURSDAY_NIGHT, SATURDAY_NOON])
def test_email_blocked_outside_business_hours(session: Session, when: datetime) -> None:
    lead = make_lead(session)
    add_basis(session, lead)
    decision = make_guard(session, now=when).check_send(lead, "email", approved=True)
    assert decision.reason == "outside_business_hours"


def test_email_max_touches_per_lead(session: Session) -> None:
    lead = make_lead(session)
    add_basis(session, lead)
    for hours in (30, 20):
        add_message(
            session, lead, "email", DIRECTION_OUT, MSG_SENT, THURSDAY_NOON - timedelta(hours=hours)
        )
    decision = make_guard(session).check_send(lead, "email", approved=True)
    assert decision.reason == "max_touches_reached"


def test_dry_run_messages_do_not_count_as_touches(session: Session) -> None:
    lead = make_lead(session)
    add_basis(session, lead)
    for _ in range(3):
        add_message(session, lead, "email", DIRECTION_OUT, "dry_run", THURSDAY_NOON)
    assert make_guard(session).check_send(lead, "email", approved=True).allowed


def test_daily_limit_counts_all_leads(session: Session) -> None:
    lead = make_lead(session)
    other = make_lead(session, phone=None, email="outro@loja.com")
    add_basis(session, lead)
    add_message(
        session, other, "email", DIRECTION_OUT, MSG_SENT, THURSDAY_NOON - timedelta(hours=1)
    )

    guard = make_guard(session, daily_send_limit=1)
    assert guard.check_send(lead, "email", approved=True).reason == "daily_limit_reached"
    assert make_guard(session, daily_send_limit=2).check_send(lead, "email", approved=True).allowed


def test_messages_from_yesterday_do_not_count_today(session: Session) -> None:
    lead = make_lead(session)
    other = make_lead(session, phone=None, email="outro@loja.com")
    add_basis(session, lead)
    add_message(session, other, "email", DIRECTION_OUT, MSG_SENT, THURSDAY_NOON - timedelta(days=1))
    guard = make_guard(session, daily_send_limit=1)
    assert guard.check_send(lead, "email", approved=True).allowed


def test_unknown_channel_is_blocked(session: Session) -> None:
    lead = make_lead(session)
    assert make_guard(session).check_send(lead, "sms", approved=True).reason == "unknown_channel"
