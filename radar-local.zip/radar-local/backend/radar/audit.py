"""Registro de auditoria: o que aconteceu, com qual lead e por quê."""

from sqlalchemy.orm import Session

from radar.models import AuditLog, utcnow


def record_audit(
    session: Session, event: str, lead_id: int | None = None, **details: object
) -> None:
    session.add(AuditLog(event=event, lead_id=lead_id, details=details, created_at=utcnow()))
