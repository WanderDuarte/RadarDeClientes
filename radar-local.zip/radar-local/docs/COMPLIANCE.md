# Compliance e uso responsável

> Este documento resume as regras que o projeto adota. **Não é aconselhamento jurídico.** Regras de
> plataformas e leis mudam: confira as políticas vigentes e consulte um advogado antes de uso comercial.

## O que o projeto NÃO faz

- **Mensagem fria por WhatsApp ou Instagram.** A Meta exige opt-in para mensagens iniciadas pela empresa
  no WhatsApp (e templates aprovados para elas), e a API do Instagram só permite responder a quem
  iniciou a conversa. Burlar isso (WhatsApp Web automatizado, bots de DM) leva a bloqueio de número e conta.
- **Scraping** de Google Maps, Instagram ou outros serviços cujos termos o proíbam.
- **Contato após opt-out.** Quem pede para parar entra na lista de supressão e nunca mais é contatado.

## LGPD (Brasil)

- Contato B2B pode se apoiar em **legítimo interesse** (art. 7º, IX), desde que haja finalidade legítima,
  transparência sobre quem você é e opt-out fácil em toda comunicação. Não vale para dados sensíveis.
- A ANPD recomenda documentar o **teste de balanceamento** (LIA) antes de tratar dados nessa base.
  Use a tabela `consents` para registrar a base legal e a evidência de cada lead/canal.
- Colete o mínimo de dados e apague o que não precisa mais.

## Fontes de dados

- **Google Places API:** use a sua chave, respeite os termos e acompanhe os custos. Há franquia gratuita
  por SKU e cobrança por mil chamadas depois dela; campos mais ricos (como site e telefone) costumam
  entrar em SKUs mais caros.
- **OpenStreetMap:** dados sob licença ODbL; mantenha a atribuição.
- **Dados abertos de CNPJ:** verifique o layout e os termos atuais antes de importar.

## O que o código garante

| Regra | Onde |
|---|---|
| Lista de supressão (telefone e e-mail normalizados) | `ComplianceGuard.is_suppressed` |
| Detecção de pedido de opt-out em mensagens recebidas | `is_opt_out` |
| WhatsApp/Instagram: só responde quem escreveu primeiro, em até 24h | `ComplianceGuard._check_reply_window` |
| E-mail frio: aprovação, base legal registrada, limite por lead, horário comercial (seg–sex) | `ComplianceGuard._check_cold` |
| Limite diário global | `ComplianceGuard._sent_today` |
| Canal desconhecido bloqueado | `ComplianceGuard.check_send` |
| Dry-run por padrão | `Settings.dry_run` + `dispatch_message` |
| Auditoria de bloqueios e envios | `radar.audit.record_audit` |

## Quem usa o projeto é responsável por

- Incluir identificação e link/instrução de **descadastro** em toda mensagem de marketing.
- Honrar pedidos de opt-out imediatamente (chame `suppress_lead` ao detectar `is_opt_out`).
- Manter as chaves de API fora do repositório.
- Revisar as mensagens geradas pela IA antes de enviar.
