# Arquitetura

## Fluxo

```
discovery → analysis → score → (IA) abordagem → aprovação → dispatch_message
                                                                │
                                          ComplianceGuard.check_send
                                                                │
                                   bloqueado → auditoria        │
                                   dry-run   → mensagem "dry_run" + auditoria
                                   liberado  → Sender.send → mensagem "sent" + auditoria
```

## Módulos

| Módulo | Responsabilidade |
|---|---|
| `discovery` | Contrato `DiscoverySource` e `save_candidates` (deduplica por `source` + `source_id`) |
| `analysis` | `score_presence`: pontua a oportunidade (0–100) e explica os motivos |
| `compliance` | `ComplianceGuard`, normalização de telefone/e-mail e `is_opt_out` |
| `outreach` | `dispatch_message`: ponto único de envio |
| `channels` | Contrato `Sender` (e-mail, WhatsApp Cloud API, Instagram) |
| `ai` | Contrato `LLMProvider` e `FakeLLM` para testes |
| `audit` | `record_audit`: registra bloqueios, dry-runs e envios |

## Status do lead

`new → analyzed → approved → contacted → replied → qualified → hot → won | lost | discarded`

## Decisões de projeto

- **Um único caminho de envio.** Nada chama um `Sender` diretamente; tudo passa por `dispatch_message`,
  que consulta o `ComplianceGuard` e grava auditoria.
- **Fail closed.** Canal desconhecido, lead em opt-out ou base legal ausente bloqueiam o envio.
- **Janela de resposta.** Em WhatsApp e Instagram só se responde a quem escreveu primeiro, em até 24h.
- **Contato frio só por e-mail** (B2B), com aprovação, base legal registrada, limite por lead e
  horário comercial. Os demais contatos frios (ligação, visita) acontecem fora do sistema.
- **Dry-run padrão.** Com `DRY_RUN=true` a mensagem é registrada, mas o `Sender` nunca é chamado.
- **Conteúdo externo é dado.** Textos de sites e perfis nunca viram instruções para a IA.

## Limitações conhecidas da v0.1

- Tabelas criadas no start da API (sem Alembic ainda).
- Envio e registro da mensagem não são atômicos: se o banco falhar logo após um envio real, a mensagem
  não é contabilizada. Será tratado junto com a fila de tarefas.
- Templates aprovados do WhatsApp (mensagens fora da janela de 24h) ainda não são suportados.
