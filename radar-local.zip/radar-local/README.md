# Radar Local

Encontra negócios locais com presença digital fraca (sem site, site ruim, Instagram abandonado) e
ajuda a abordá-los **de forma responsável**: a IA prepara a abordagem e conduz a conversa depois que o
lead responde, e você entra só para fechar o negócio.

> **Status: v0.1 (base do projeto).** Já existem a API, o banco, o score de presença digital e a camada
> de compliance, todos com testes. Descoberta de lojas, análise de sites, IA e canais reais chegam nas
> próximas versões (veja o [roadmap](#roadmap)).

## Como funciona

```
Descobrir negócios → Analisar presença digital → Score de oportunidade
   → IA escreve a abordagem (você aprova)
   → Contato frio só por canal permitido (e-mail com opt-out, ligação, visita, formulário do site)
   → O lead responde ou chama no seu WhatsApp/Instagram
   → IA conversa e qualifica dentro da janela de resposta
   → Lead quente: a IA pausa e te avisa para fechar
```

## Princípios

1. **Compliance por padrão.** Opt-out é respeitado sempre, WhatsApp e Instagram só respondem quem
   escreveu primeiro, e o envio real vem **desligado** (`DRY_RUN=true`).
2. **Humano no controle.** Primeiros contatos exigem aprovação. A IA não inventa preço nem prazo.
3. **Sem scraping.** Dados vêm de APIs oficiais, dados abertos ou do que você cadastra.
4. **Cada pessoa usa as próprias chaves.** O projeto não embute credenciais.

Leia [docs/COMPLIANCE.md](docs/COMPLIANCE.md) antes de usar com dados reais.

## Rodando

### Com Docker

```bash
cp .env.example .env
docker compose up --build
curl http://localhost:8000/health        # {"status":"ok"}
```

Documentação interativa da API: http://localhost:8000/docs

### Sem Docker

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
cp ../.env.example .env
uvicorn radar.main:app --reload
```

### Testes e qualidade

```bash
cd backend
pytest -q
ruff check . && ruff format --check . && mypy radar
```

## Estrutura

```
backend/radar/
  api/          rotas (health, leads)
  discovery/    contrato das fontes de descoberta + salvamento sem duplicados
  analysis/     score de presença digital
  compliance/   ComplianceGuard: opt-out, janela de resposta, limites, horário comercial
  outreach/     dispatch_message: único caminho de envio
  channels/     contrato dos canais de envio
  ai/           contrato dos provedores de IA
docs/           arquitetura e compliance
```

## Roadmap

- [x] v0.1: API, modelos, score, guarda de compliance, CI
- [ ] v0.2: descoberta (Google Places com chave própria e OpenStreetMap) + CLI
- [ ] v0.3: análise de sites (HTTPS, mobile, PageSpeed) e score automático
- [ ] v0.4: painel web (lista de leads, filtros, aprovação de abordagens)
- [ ] v0.5: IA que escreve abordagens (com aprovação) e envio por e-mail com opt-out
- [ ] v0.6: WhatsApp Cloud API para conversas iniciadas pelo lead + handoff para você fechar
- [ ] Alembic para migrações, fila de tarefas, documentação em inglês

## Contribuindo

Veja [CONTRIBUTING.md](CONTRIBUTING.md). Ideias e bugs entram como issues.

## Aviso legal

Este software é fornecido sem garantias e **não é aconselhamento jurídico**. Quem o usa é responsável
por cumprir a LGPD, os termos das plataformas (Meta, Google) e a legislação de consumo. Não use para
spam.

## Licença

[MIT](LICENSE)
