from collections.abc import Iterator
from typing import Any
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from radar import models  # noqa: F401
from radar.config import Settings
from radar.db import Base, get_db
from radar.main import create_app
from radar.models import Lead


@pytest.fixture
def engine() -> Iterator[Engine]:
    eng = create_engine(
        "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
    )
    Base.metadata.create_all(eng)
    yield eng
    eng.dispose()


@pytest.fixture
def session(engine: Engine) -> Iterator[Session]:
    with Session(engine, expire_on_commit=False) as s:
        yield s


@pytest.fixture
def client(engine: Engine) -> TestClient:
    factory = sessionmaker(bind=engine, expire_on_commit=False)

    def override() -> Iterator[Session]:
        with factory() as s:
            yield s

    app = create_app()
    app.dependency_overrides[get_db] = override
    return TestClient(app)


def make_settings(**overrides: Any) -> Settings:
    values: dict[str, Any] = {
        "database_url": "sqlite://",
        "dry_run": False,
        "require_approval": True,
        "daily_send_limit": 20,
        "max_cold_touches_per_lead": 2,
        "business_hours_start": 9,
        "business_hours_end": 18,
        "timezone": "America/Sao_Paulo",
    }
    values.update(overrides)
    return Settings(_env_file=None, **values)


def make_lead(session: Session, **overrides: Any) -> Lead:
    fields: dict[str, Any] = {
        "name": "Padaria Teste",
        "source": "manual",
        "source_id": uuid4().hex,
        "phone": "(18) 99999-0000",
        "email": "contato@padaria.com",
    }
    fields.update(overrides)
    lead = Lead(**fields)
    session.add(lead)
    session.commit()
    return lead
