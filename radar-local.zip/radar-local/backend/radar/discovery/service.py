from collections.abc import Iterable

from sqlalchemy import select
from sqlalchemy.orm import Session

from radar.discovery.base import PlaceCandidate
from radar.models import Lead


def save_candidates(session: Session, candidates: Iterable[PlaceCandidate]) -> int:
    """Salva candidatos como leads, ignorando duplicados. Devolve quantos foram criados."""
    created = 0
    seen: set[tuple[str, str]] = set()
    for c in candidates:
        key = (c.source, c.source_id)
        if key in seen:
            continue
        seen.add(key)
        exists = session.scalar(
            select(Lead.id).where(Lead.source == c.source, Lead.source_id == c.source_id)
        )
        if exists is not None:
            continue
        session.add(
            Lead(
                name=c.name,
                category=c.category,
                address=c.address,
                city=c.city,
                phone=c.phone,
                website=c.website,
                source=c.source,
                source_id=c.source_id,
            )
        )
        created += 1
    session.commit()
    return created
