"""Contrato dos provedores de IA. A implementação real (Claude, OpenAI, local...) entra depois."""

from typing import Protocol


class LLMProvider(Protocol):
    def complete(self, *, system: str, user: str) -> str: ...


class FakeLLM:
    """Provedor falso para testes: devolve sempre a mesma resposta e guarda as chamadas."""

    def __init__(self, reply: str = "ok") -> None:
        self.reply = reply
        self.calls: list[tuple[str, str]] = []

    def complete(self, *, system: str, user: str) -> str:
        self.calls.append((system, user))
        return self.reply
