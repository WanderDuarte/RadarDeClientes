---
name: Bug
about: Algo não funciona como deveria
labels: bug
---

**O que aconteceu**

**O que você esperava**

**Como reproduzir**

**Ambiente** (SO, Python, Docker ou local)

> Não cole chaves de API, tokens nem dados pessoais de leads neste issue.
