# Código de conduta

Queremos uma comunidade respeitosa e acolhedora para quem contribui, independentemente de
experiência, origem, identidade ou opinião.

## Esperamos

- Respeito, empatia e críticas construtivas.
- Foco no que é melhor para o projeto e para as pessoas que o usam.
- Honestidade sobre limitações e erros.

## Não toleramos

- Assédio, discriminação, ataques pessoais ou linguagem ofensiva.
- Uso do projeto para spam, golpes ou contato com quem pediu para não ser contatado.
- Publicar dados pessoais de terceiros.

## Aplicação

Quem mantém o projeto pode remover comentários, issues e contribuições que violem este código e
banir quem o descumprir repetidamente. Para denunciar, entre em contato com quem mantém o
repositório por um canal privado (veja o perfil no GitHub).

Inspirado no [Contributor Covenant](https://www.contributor-covenant.org/pt-br/version/2/1/code_of_conduct/).
