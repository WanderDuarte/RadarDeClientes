"""Contrato das fontes de descoberta de negócios.

Cada fonte (Google Places, OpenStreetMap, dados abertos de CNPJ...) vira um adaptador
que devolve `PlaceCandidate`. Os adaptadores entram na v0.2.
"""

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class PlaceCandidate:
    source: str
    source_id: str
    name: str
    category: str | None = None
    address: str | None = None
    city: str | None = None
    phone: str | None = None
    website: str | None = None


class DiscoverySource(Protocol):
    name: str

    def search(self, *, city: str, category: str, limit: int = 20) -> list[PlaceCandidate]: ...
