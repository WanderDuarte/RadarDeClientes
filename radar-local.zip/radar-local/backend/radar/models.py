"""Modelos do banco de dados."""

import enum
from datetime import UTC, datetime

from sqlalchemy import JSON, DateTime, ForeignKey, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from radar.db import Base

# Direção e status das mensagens
DIRECTION_IN = "in"
DIRECTION_OUT = "out"
MSG_SENT = "sent"
MSG_DRY_RUN = "dry_run"
MSG_RECEIVED = "received"


def utcnow() -> datetime:
    return datetime.now(UTC)


class LeadStatus(enum.StrEnum):
    NEW = "new"
    ANALYZED = "analyzed"
    APPROVED = "approved"
    CONTACTED = "contacted"
    REPLIED = "replied"
    QUALIFIED = "qualified"
    HOT = "hot"
    WON = "won"
    LOST = "lost"
    DISCARDED = "discarded"


class LegalBasis(enum.StrEnum):
    CONSENT = "consent"
    LEGITIMATE_INTEREST = "legitimate_interest"


class Lead(Base):
    __tablename__ = "leads"
    __table_args__ = (UniqueConstraint("source", "source_id", name="uq_lead_source"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    category: Mapped[str | None] = mapped_column(String(100))
    address: Mapped[str | None] = mapped_column(Text)
    city: Mapped[str | None] = mapped_column(String(100))
    phone: Mapped[str | None] = mapped_column(String(32))
    email: Mapped[str | None] = mapped_column(String(254))
    website: Mapped[str | None] = mapped_column(String(500))
    instagram_url: Mapped[str | None] = mapped_column(String(500))
    source: Mapped[str] = mapped_column(String(50))
    source_id: Mapped[str] = mapped_column(String(200))
    score: Mapped[int | None]
    score_reasons: Mapped[list[str]] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(20), default=LeadStatus.NEW.value)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(primary_key=True)
    lead_id: Mapped[int] = mapped_column(ForeignKey("leads.id"), index=True)
    channel: Mapped[str] = mapped_column(String(20))
    direction: Mapped[str] = mapped_column(String(3))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20))
    provider_message_id: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class Consent(Base):
    """Base legal registrada para contatar um lead em um canal."""

    __tablename__ = "consents"

    id: Mapped[int] = mapped_column(primary_key=True)
    lead_id: Mapped[int] = mapped_column(ForeignKey("leads.id"), index=True)
    channel: Mapped[str] = mapped_column(String(20))
    basis: Mapped[str] = mapped_column(String(30))
    evidence: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class SuppressionEntry(Base):
    """Quem pediu para não ser contatado (opt-out). Consultada antes de qualquer envio."""

    __tablename__ = "suppression_list"
    __table_args__ = (UniqueConstraint("kind", "value", name="uq_suppression"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(10))  # "phone" | "email"
    value: Mapped[str] = mapped_column(String(254))
    reason: Mapped[str] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    event: Mapped[str] = mapped_column(String(50), index=True)
    lead_id: Mapped[int | None] = mapped_column(index=True)
    details: Mapped[dict[str, object]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
