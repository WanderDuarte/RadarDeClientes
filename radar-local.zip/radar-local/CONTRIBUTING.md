# Como contribuir

Obrigado por querer ajudar! Antes de começar, leia o [código de conduta](CODE_OF_CONDUCT.md) e o
[guia de compliance](docs/COMPLIANCE.md).

## Preparando o ambiente

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

## Antes de abrir um PR

```bash
ruff check . && ruff format --check . && mypy radar && pytest -q
```

O CI roda exatamente isso.

## Regras do projeto

1. **Compliance não é opcional.** Todo envio passa por `ComplianceGuard` via `dispatch_message`.
   PRs que criem outro caminho de envio, desliguem o opt-out ou removam limites serão recusados.
2. **Sem scraping** de Google Maps, Instagram ou qualquer serviço cujos termos proíbam isso.
3. **Sem segredos no repositório.** Chaves vão em variáveis de ambiente.
4. **Teste o que mudar.** Código novo vem com testes; comportamento de compliance exige testes de bloqueio.
5. **Commits** no formato `tipo: resumo` (`feat`, `fix`, `docs`, `test`, `refactor`, `chore`).

## Boas primeiras contribuições

Procure issues com a etiqueta `good first issue`: adaptadores de descoberta, novos critérios de score,
traduções da documentação e testes.
