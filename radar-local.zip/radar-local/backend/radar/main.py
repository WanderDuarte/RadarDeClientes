from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from radar import __version__, models  # noqa: F401  (importa os modelos para o create_all)
from radar.api import health, leads
from radar.db import Base, get_engine


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    # Para o MVP criamos as tabelas na subida. Migrações (Alembic) entram numa versão futura.
    Base.metadata.create_all(get_engine())
    yield


def create_app() -> FastAPI:
    app = FastAPI(title="Radar Local", version=__version__, lifespan=lifespan)
    app.include_router(health.router)
    app.include_router(leads.router)
    return app


app = create_app()
