from datetime import UTC, datetime

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from radar.compliance.guard import ComplianceGuard
from radar.models import AuditLog, Consent, Lead, Message
from radar.outreach.service import dispatch_message
from tests.conftest import make_lead, make_settings

NOON = datetime(2026, 11, 19, 15, 0, tzinfo=UTC)  # quinta, 12h em São Paulo


class FakeSender:
    channel = "email"

    def __init__(self) -> None:
        self.sent: list[tuple[int, str]] = []

    def send(self, lead: Lead, body: str) -> str:
        self.sent.append((lead.id, body))
        return "provider-1"


def _setup(session: Session, **settings: object):
    lead = make_lead(session)
    session.add(Consent(lead_id=lead.id, channel="email", basis="legitimate_interest"))
    session.commit()
    cfg = make_settings(**settings)
    return lead, cfg, ComplianceGuard(session, cfg, now=lambda: NOON), FakeSender()


def _events(session: Session) -> list[str]:
    return list(session.scalars(select(AuditLog.event).order_by(AuditLog.id)))


def test_real_send_records_message_and_audit(session: Session) -> None:
    lead, cfg, guard, sender = _setup(session)
    result = dispatch_message(session, guard, cfg, sender, lead, "email", "Olá!", approved=True)

    assert (result.sent, result.status) == (True, "sent")
    assert sender.sent == [(lead.id, "Olá!")]
    msg = session.scalars(select(Message)).one()
    assert (msg.status, msg.provider_message_id) == ("sent", "provider-1")
    assert _events(session) == ["message_sent"]


def test_dry_run_never_calls_the_sender(session: Session) -> None:
    lead, cfg, guard, sender = _setup(session, dry_run=True)
    result = dispatch_message(session, guard, cfg, sender, lead, "email", "Olá!", approved=True)

    assert (result.sent, result.status) == (False, "dry_run")
    assert sender.sent == []
    assert session.scalars(select(Message)).one().status == "dry_run"
    assert _events(session) == ["message_dry_run"]


def test_blocked_message_is_audited_and_not_sent(session: Session) -> None:
    lead, cfg, guard, sender = _setup(session)
    result = dispatch_message(session, guard, cfg, sender, lead, "email", "Olá!", approved=False)

    assert (result.status, result.reason) == ("blocked", "approval_required")
    assert sender.sent == []
    assert session.scalars(select(Message)).all() == []
    assert _events(session) == ["send_blocked"]


def test_opt_out_lead_is_never_sent(session: Session) -> None:
    lead, cfg, guard, sender = _setup(session)
    guard.suppress_lead(lead, "opt_out")
    session.commit()
    result = dispatch_message(session, guard, cfg, sender, lead, "email", "Olá!", approved=True)
    assert result.reason == "suppressed"
    assert sender.sent == []


def test_sender_for_wrong_channel_is_rejected(session: Session) -> None:
    lead, cfg, guard, sender = _setup(session)
    with pytest.raises(ValueError):
        dispatch_message(session, guard, cfg, sender, lead, "whatsapp", "Olá!")
