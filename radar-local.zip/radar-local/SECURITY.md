# Política de segurança

## Como reportar uma vulnerabilidade

**Não abra um issue público.** Use o recurso *Report a vulnerability* na aba **Security** do repositório
(relato privado). Descreva o problema, os passos para reproduzir e o impacto.

## O que é considerado sensível neste projeto

- Vazamento de chaves de API ou tokens (WhatsApp, Instagram, Google, provedores de IA).
- Exposição de dados pessoais de leads (telefones, e-mails, conversas).
- Qualquer forma de contornar a lista de supressão (opt-out) ou os limites de envio.
- Prompt injection que faça a IA executar ações fora do previsto (enviar mensagens, vazar dados).

## Boas práticas para quem usa

- Nunca faça commit do `.env`.
- Troque a senha do banco do `docker-compose.yml` em qualquer ambiente que não seja o seu computador.
- Mantenha `DRY_RUN=true` até validar tudo.
