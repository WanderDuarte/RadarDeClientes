"""Configuração via variáveis de ambiente (ou arquivo .env).

Os valores padrão são os mais restritivos de propósito: nada é enviado de verdade
até que a pessoa desligue o DRY_RUN conscientemente.
"""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    database_url: str = "sqlite:///./radar.db"

    # Segurança / compliance
    dry_run: bool = True
    require_approval: bool = True
    daily_send_limit: int = 20
    max_cold_touches_per_lead: int = 3
    business_hours_start: int = 9
    business_hours_end: int = 18
    timezone: str = "America/Sao_Paulo"

    # Fontes de dados (cada pessoa usa a própria chave)
    google_places_api_key: str = ""


@lru_cache
def get_settings() -> Settings:
    return Settings()
