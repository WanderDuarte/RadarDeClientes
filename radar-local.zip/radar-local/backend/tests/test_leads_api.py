from fastapi.testclient import TestClient


def test_create_and_list_leads(client: TestClient) -> None:
    created = client.post("/leads", json={"name": "Barbearia do Zé", "city": "Araçatuba"})
    assert created.status_code == 201
    body = created.json()
    assert body["name"] == "Barbearia do Zé"
    assert body["status"] == "new"
    assert body["score"] is None
    assert body["score_reasons"] == []

    listed = client.get("/leads")
    assert listed.status_code == 200
    assert [lead["name"] for lead in listed.json()] == ["Barbearia do Zé"]


def test_duplicate_source_id_returns_409(client: TestClient) -> None:
    payload = {"name": "Loja A", "source": "osm", "source_id": "node/1"}
    assert client.post("/leads", json=payload).status_code == 201
    assert client.post("/leads", json=payload).status_code == 409


def test_filters_by_status_and_validates_params(client: TestClient) -> None:
    client.post("/leads", json={"name": "Loja B"})
    assert client.get("/leads", params={"status": "won"}).json() == []
    assert client.get("/leads", params={"min_score": 101}).status_code == 422


def test_empty_name_is_rejected(client: TestClient) -> None:
    assert client.post("/leads", json={"name": ""}).status_code == 422
