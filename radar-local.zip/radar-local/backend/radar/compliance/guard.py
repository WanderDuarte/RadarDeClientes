"""Guarda de compliance: o único caminho para decidir se uma mensagem pode ser enviada.

Regras embutidas (veja docs/COMPLIANCE.md):
- Quem pediu opt-out nunca é contatado (lista de supressão).
- WhatsApp e Instagram: só respondemos quem escreveu primeiro, dentro da janela de 24h.
- E-mail (contato frio B2B): exige aprovação humana, base legal registrada, limite de contatos
  por lead e horário comercial.
- Limite diário global. Canal desconhecido é bloqueado.
"""

import re
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from radar.config import Settings
from radar.models import (
    DIRECTION_IN,
    DIRECTION_OUT,
    MSG_SENT,
    Consent,
    Lead,
    Message,
    SuppressionEntry,
)

WINDOW_CHANNELS: dict[str, timedelta] = {
    "whatsapp": timedelta(hours=24),
    "instagram": timedelta(hours=24),
}
COLD_CHANNELS = {"email"}

_OPT_OUT_PHRASES = (
    "nao quero receber",
    "nao quero mais receber",
    "nao me envie",
    "nao me mande",
    "nao envie mais",
    "parem de",
    "pare de",
    "parar de",
    "me remova",
    "me remove",
    "remover meu",
    "descadastr",
    "cancelar inscricao",
    "cancele minha inscricao",
)
_OPT_OUT_KEYWORDS = {"pare", "parar", "stop", "sair", "cancelar", "descadastrar", "remover"}


def normalize_phone(raw: str) -> str:
    digits = re.sub(r"\D", "", raw)
    if len(digits) in (10, 11):  # DDD + número, sem código do país
        return "55" + digits
    return digits


def normalize_email(raw: str) -> str:
    return raw.strip().lower()


def _strip_accents(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))


def is_opt_out(text: str) -> bool:
    """Detecta pedido de descadastro. Na dúvida, erra para o lado de proteger a pessoa."""
    norm = _strip_accents(text).lower().strip()
    if any(phrase in norm for phrase in _OPT_OUT_PHRASES):
        return True
    words = re.findall(r"[a-z]+", norm)
    return 0 < len(words) <= 3 and any(w in _OPT_OUT_KEYWORDS for w in words)


@dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: str


class ComplianceGuard:
    def __init__(
        self,
        session: Session,
        settings: Settings,
        now: Callable[[], datetime] | None = None,
    ) -> None:
        self.session = session
        self.settings = settings
        self._now = now or (lambda: datetime.now(UTC))

    def now(self) -> datetime:
        return self._now()

    # --- lista de supressão -------------------------------------------------

    def add_suppression(self, kind: str, value: str, reason: str) -> None:
        if kind == "phone":
            norm = normalize_phone(value)
        elif kind == "email":
            norm = normalize_email(value)
        else:
            raise ValueError(f"kind inválido: {kind!r}")
        exists = self.session.scalar(
            select(SuppressionEntry.id).where(
                SuppressionEntry.kind == kind, SuppressionEntry.value == norm
            )
        )
        if exists is None:
            self.session.add(SuppressionEntry(kind=kind, value=norm, reason=reason))
            self.session.flush()

    def suppress_lead(self, lead: Lead, reason: str) -> None:
        if lead.phone:
            self.add_suppression("phone", lead.phone, reason)
        if lead.email:
            self.add_suppression("email", lead.email, reason)

    def is_suppressed(self, lead: Lead) -> bool:
        conditions = []
        if lead.phone:
            conditions.append(
                and_(
                    SuppressionEntry.kind == "phone",
                    SuppressionEntry.value == normalize_phone(lead.phone),
                )
            )
        if lead.email:
            conditions.append(
                and_(
                    SuppressionEntry.kind == "email",
                    SuppressionEntry.value == normalize_email(lead.email),
                )
            )
        if not conditions:
            return False
        count = self.session.scalar(
            select(func.count()).select_from(SuppressionEntry).where(or_(*conditions))
        )
        return bool(count)

    # --- decisão de envio ---------------------------------------------------

    def check_send(self, lead: Lead, channel: str, *, approved: bool = False) -> Decision:
        if self.is_suppressed(lead):
            return Decision(False, "suppressed")

        if channel in WINDOW_CHANNELS:
            decision = self._check_reply_window(lead, channel)
        elif channel in COLD_CHANNELS:
            decision = self._check_cold(lead, channel, approved)
        else:
            return Decision(False, "unknown_channel")

        if not decision.allowed:
            return decision
        if self._sent_today() >= self.settings.daily_send_limit:
            return Decision(False, "daily_limit_reached")
        return Decision(True, "ok")

    def _check_reply_window(self, lead: Lead, channel: str) -> Decision:
        last_in = self.session.scalar(
            select(func.max(Message.created_at)).where(
                Message.lead_id == lead.id,
                Message.channel == channel,
                Message.direction == DIRECTION_IN,
            )
        )
        if last_in is None:
            return Decision(False, "no_inbound_message")
        if last_in.tzinfo is None:
            last_in = last_in.replace(tzinfo=UTC)
        if self.now() - last_in > WINDOW_CHANNELS[channel]:
            return Decision(False, "reply_window_closed")
        return Decision(True, "ok")

    def _check_cold(self, lead: Lead, channel: str, approved: bool) -> Decision:
        if self.settings.require_approval and not approved:
            return Decision(False, "approval_required")

        has_basis = self.session.scalar(
            select(func.count())
            .select_from(Consent)
            .where(Consent.lead_id == lead.id, Consent.channel == channel)
        )
        if not has_basis:
            return Decision(False, "no_legal_basis_recorded")

        touches = self.session.scalar(
            select(func.count())
            .select_from(Message)
            .where(
                Message.lead_id == lead.id,
                Message.channel == channel,
                Message.direction == DIRECTION_OUT,
                Message.status == MSG_SENT,
            )
        )
        if (touches or 0) >= self.settings.max_cold_touches_per_lead:
            return Decision(False, "max_touches_reached")

        if not self._in_business_hours():
            return Decision(False, "outside_business_hours")
        return Decision(True, "ok")

    def _in_business_hours(self) -> bool:
        local = self.now().astimezone(ZoneInfo(self.settings.timezone))
        return local.weekday() < 5 and (
            self.settings.business_hours_start <= local.hour < self.settings.business_hours_end
        )

    def _sent_today(self) -> int:
        tz = ZoneInfo(self.settings.timezone)
        local_now = self.now().astimezone(tz)
        start_utc = local_now.replace(hour=0, minute=0, second=0, microsecond=0).astimezone(UTC)
        count = self.session.scalar(
            select(func.count())
            .select_from(Message)
            .where(
                Message.direction == DIRECTION_OUT,
                Message.status == MSG_SENT,
                Message.created_at >= start_utc,
            )
        )
        return count or 0
