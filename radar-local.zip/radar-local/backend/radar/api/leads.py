from typing import Annotated
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from radar.db import get_db
from radar.models import Lead
from radar.schemas import LeadCreate, LeadOut

router = APIRouter(prefix="/leads", tags=["leads"])

DbSession = Annotated[Session, Depends(get_db)]


@router.post("", response_model=LeadOut, status_code=201)
def create_lead(payload: LeadCreate, db: DbSession) -> Lead:
    data = payload.model_dump(exclude={"source_id"})
    lead = Lead(**data, source_id=payload.source_id or uuid4().hex)
    db.add(lead)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409, detail="Lead já existe (mesma source/source_id)"
        ) from None
    db.refresh(lead)
    return lead


@router.get("", response_model=list[LeadOut])
def list_leads(
    db: DbSession,
    min_score: Annotated[int | None, Query(ge=0, le=100)] = None,
    status: str | None = None,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> list[Lead]:
    stmt = select(Lead).order_by(Lead.score.desc().nulls_last(), Lead.id)
    if min_score is not None:
        stmt = stmt.where(Lead.score >= min_score)
    if status is not None:
        stmt = stmt.where(Lead.status == status)
    return list(db.scalars(stmt.limit(limit)))
