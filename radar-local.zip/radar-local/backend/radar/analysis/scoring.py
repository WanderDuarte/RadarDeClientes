"""Score de oportunidade (0-100): quanto maior, mais a presença digital do negócio pode melhorar.

Valores `None` significam "não sabemos" e não somam pontos. Os pesos podem ser sobrescritos.
"""

from dataclasses import dataclass, field

DEFAULT_WEIGHTS: dict[str, int] = {
    "no_website": 60,
    "website_unreachable": 45,
    "no_https": 10,
    "not_mobile_friendly": 15,
    "slow_pagespeed": 10,
    "no_cta": 10,
    "no_instagram": 40,
    "instagram_inactive": 20,
}

SLOW_PAGESPEED_THRESHOLD = 50


@dataclass(frozen=True)
class PresenceAnalysis:
    has_website: bool
    website_reachable: bool | None = None
    https: bool | None = None
    mobile_friendly: bool | None = None
    pagespeed_mobile: int | None = None
    has_cta: bool | None = None
    has_instagram_link: bool = False
    instagram_inactive: bool | None = None


@dataclass(frozen=True)
class ScoreResult:
    score: int
    reasons: list[str] = field(default_factory=list)


def score_presence(
    analysis: PresenceAnalysis, weights: dict[str, int] | None = None
) -> ScoreResult:
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    total = 0
    reasons: list[str] = []

    def add(key: str, reason: str) -> None:
        nonlocal total
        total += w[key]
        reasons.append(reason)

    if not analysis.has_website:
        add("no_website", "Não possui site")
    elif analysis.website_reachable is False:
        add("website_unreachable", "Site fora do ar ou inacessível na análise")
    else:
        if analysis.https is False:
            add("no_https", "Site sem HTTPS")
        if analysis.mobile_friendly is False:
            add("not_mobile_friendly", "Site não adaptado para celular")
        if (
            analysis.pagespeed_mobile is not None
            and analysis.pagespeed_mobile < SLOW_PAGESPEED_THRESHOLD
        ):
            add("slow_pagespeed", "Site lento no celular")
        if analysis.has_cta is False:
            add("no_cta", "Site sem chamada para ação (WhatsApp, contato, orçamento)")

    if not analysis.has_instagram_link:
        add("no_instagram", "Instagram não identificado")
    elif analysis.instagram_inactive:
        add("instagram_inactive", "Instagram sem postagens recentes")

    return ScoreResult(score=min(total, 100), reasons=reasons)
