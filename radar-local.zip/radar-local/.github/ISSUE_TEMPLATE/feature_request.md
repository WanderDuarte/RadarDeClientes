---
name: Ideia / funcionalidade
about: Sugira uma melhoria
labels: enhancement
---

**Problema que isso resolve**

**Proposta**

**Alternativas consideradas**

> Propostas que contornem a camada de compliance (opt-out, janela de resposta, limites) não serão aceitas.
